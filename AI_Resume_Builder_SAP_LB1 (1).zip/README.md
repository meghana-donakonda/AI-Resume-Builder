# AI Resume Builder — SAP Learning Block 1

## Project
A GenAI-inspired resume builder that collects candidate information, generates a professional summary, shows a live resume preview, and provides a print/PDF workflow.

## How to run
1. Open `index.html` in Chrome/Edge.
2. Enter resume information.
3. Click **Generate with AI**.
4. Review the generated summary.
5. Click **Update Resume**.
6. Click **Download / Print PDF** and choose Save as PDF.

## Important for the Learning Block report
The current demo uses browser-side generation logic so it works without an API key. For a true GenAI integration, connect the Generate with AI action to a backend endpoint that calls an approved GenAI model/API. Never put a private API key directly in frontend JavaScript.

## Suggested report title
AI Resume Builder Using Generative AI

## Main features
- Resume information form
- AI-assisted professional summary
- Live resume preview
- Skills, projects, education, experience and certification sections
- Print/save as PDF
- Responsive interface
